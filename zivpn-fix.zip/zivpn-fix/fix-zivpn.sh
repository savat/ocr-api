#!/bin/bash
# fix-zivpn.sh  -  รันบนเซิร์ฟเวอร์ด้วย root:  bash fix-zivpn.sh
# 1) ล้าง /root/username.db ให้เหลือเฉพาะบัญชี SSH จริง (ตัด ubuntu/lxd/systemd-* และชื่อ ZIVPN ที่หลุดเข้ามา)
# 2) ติดตั้ง menu.sh ใหม่เป็นคำสั่ง m (ถ้าวาง menu.sh ไว้โฟลเดอร์เดียวกัน)
# 3) เปิด badvpn-udpgw ที่ 127.0.0.1:7300 (แก้ error connection refused)
[ "$(id -u)" -eq 0 ] || { echo "ต้องรันด้วย root"; exit 1; }
DIR=$(cd "$(dirname "$0")" && pwd)

# ---- 1) username.db
DB=/root/username.db
if [ -f "$DB" ]; then
  cp -f "$DB" "$DB.bak.$(date +%s)"
  : > "$DB.new"
  while read -r n lim _; do
    [ -z "$n" ] && continue
    ent=$(getent passwd "$n") || { echo "  ตัดออก (ไม่มีบัญชีระบบ/ของ ZIVPN): $n"; continue; }
    uid=$(echo "$ent" | cut -d: -f3); sh=$(echo "$ent" | cut -d: -f7)
    if [ -f "/etc/AutoScript/senha/$n" ] || { [ "$uid" -ge 1000 ] && [ "$uid" -lt 60000 ] && { [ "$sh" = /bin/false ] || [ "$sh" = /usr/sbin/nologin ]; }; }; then
      echo "$n ${lim:-1}" >> "$DB.new"
    else
      echo "  ตัดออก (บัญชีระบบ): $n"
    fi
  done < "$DB"
  mv -f "$DB.new" "$DB"; echo "✔ ล้าง $DB แล้ว (สำรองไว้ที่ $DB.bak.*)"
fi

# ---- 2) คำสั่ง m
if [ -f "$DIR/menu.sh" ] || [ -f "$DIR/zivpn/menu.sh" ]; then
  src="$DIR/menu.sh"; [ -f "$src" ] || src="$DIR/zivpn/menu.sh"
  install -m 755 "$src" /usr/local/bin/m && echo "✔ อัปเดตคำสั่ง m"
else
  echo "! ไม่พบ menu.sh ข้าง ๆ สคริปต์นี้ - ข้ามขั้นตอนอัปเดต m"
fi

# ---- 3) udpgw
UB=""; for b in /bin/badvpn-udpgw /usr/bin/badvpn-udpgw /usr/local/bin/badvpn-udpgw; do [ -x "$b" ] && UB=$b && break; done
[ -z "$UB" ] && [ -f "$DIR/Install/badvpn-udpgw" ] && install -m 755 "$DIR/Install/badvpn-udpgw" /usr/local/bin/badvpn-udpgw && UB=/usr/local/bin/badvpn-udpgw
if [ -z "$UB" ]; then echo "✘ ไม่พบ badvpn-udpgw (วางไฟล์ Install/badvpn-udpgw ไว้ข้าง ๆ แล้วรันใหม่)"; exit 1; fi
if ss -lntH 2>/dev/null | grep -qE '[:.]7300[[:space:]]' && ! systemctl is-active --quiet zivpn-udpgw; then
  echo "✔ มีโปรแกรมรันที่พอร์ต 7300 อยู่แล้ว - ไม่สร้างซ้ำ"
else
  cat > /etc/systemd/system/zivpn-udpgw.service <<UNIT
[Unit]
Description=ZIVPN - badvpn-udpgw (127.0.0.1:7300)
After=network.target
Before=zivpn.service

[Service]
ExecStart=$UB --listen-addr 127.0.0.1:7300 --max-clients 1000 --max-connections-for-client 1000
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
UNIT
  systemctl daemon-reload && systemctl enable --now zivpn-udpgw && echo "✔ เปิด udpgw :7300 แล้ว"
fi
echo; ss -lntp | grep 7300; echo; m online
